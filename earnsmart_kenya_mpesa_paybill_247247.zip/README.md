# EarnSmart Kenya — M-Pesa STK Push payment system

This package adds a server-side Daraja/M-Pesa Express payment layer for:
- Starter — KES 99/month
- Pro — KES 249/month
- Premium — KES 499/month

## Important
This package is **not live by itself**. It requires:
1. A Safaricom Daraja account and app credentials.
2. A live M-Pesa Till/PayBill for production.
3. A public HTTPS callback URL.
4. A database/payment ledger to persist pending and completed payments.
5. Server-side entitlement logic before granting Premium/Pro/Starter access.

Safaricom documents M-Pesa Express as the API for initiating Buy Goods or PayBill payments to a merchant's Till/PayBill, and states that API responses are asynchronous and delivered to callback URLs. For PayBill payments, the account reference is the customer's PayBill account number. Production requires an M-Pesa account (PayBill/Till) and appropriate M-Pesa Portal access.

## Sandbox
1. Copy `.env.example` to `.env`.
2. Put your sandbox credentials in `.env`.
3. For the EarnSmart Kenya PayBill configuration, set `MPESA_SHORT_CODE=247247` and `MPESA_ACCOUNT_REFERENCE=0100187646034`. Set your sandbox `MPESA_PASSKEY` and an HTTPS callback URL that reaches this server.
4. Run:
   npm install
   npm start

## Production
Change `DARAJA_BASE_URL` to the production endpoint provided by Safaricom after Go Live, use production credentials, and use PayBill 247247 with account reference 0100187646034. The STK Push request uses `CustomerPayBillOnline` because this configuration is a PayBill, not a Till. Never put Consumer Secret, Passkey, or other secrets in browser JavaScript.

## Security
- Never trust the amount or plan sent by the browser; this server uses a fixed server-side price table.
- Never activate a membership from the browser's success message.
- Persist CheckoutRequestID and associate it with the authenticated user and selected plan.
- Process Safaricom's callback idempotently.
- Verify callback/payment details against the pending payment record.
- Add authentication, rate limiting, request validation, HTTPS, secure headers, database transactions, audit logs, and webhook/source controls before production.
- Consider a reconciliation/status check when a callback is not received.

Official Safaricom documentation:
https://developer.safaricom.co.ke/apis
https://developer.safaricom.co.ke/apis/GettingStarted
https://developer.safaricom.co.ke/apis/Authorization
https://developer.safaricom.co.ke/apis/TransactionStatus

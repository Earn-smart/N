const express = require("express");
const crypto = require("crypto");
const app = express();

app.use(express.json({limit: "100kb"}));

const PORT = process.env.PORT || 3000;
const DARAJA_BASE = process.env.DARAJA_BASE_URL || "https://sandbox.safaricom.co.ke";
const CONSUMER_KEY = process.env.DARAJA_CONSUMER_KEY;
const CONSUMER_SECRET = process.env.DARAJA_CONSUMER_SECRET;
const SHORT_CODE = process.env.MPESA_SHORT_CODE;
const PASSKEY = process.env.MPESA_PASSKEY;
const CALLBACK_URL = process.env.MPESA_CALLBACK_URL;
const ACCOUNT_REFERENCE = process.env.MPESA_ACCOUNT_REFERENCE || "0100187646034";
const TRANSACTION_DESC = "EarnSmart Kenya Limited";

const PLANS = Object.freeze({
  starter: { name: "Starter", amount: 99 },
  pro: { name: "Pro", amount: 249 },
  premium: { name: "Premium", amount: 499 }
});

function requireEnv() {
  const missing = [];
  for (const [k,v] of Object.entries({
    DARAJA_CONSUMER_KEY: CONSUMER_KEY,
    DARAJA_CONSUMER_SECRET: CONSUMER_SECRET,
    MPESA_SHORT_CODE: SHORT_CODE,
    MPESA_PASSKEY: PASSKEY,
    MPESA_CALLBACK_URL: CALLBACK_URL
  })) if (!v) missing.push(k);
  if (missing.length) throw new Error("Missing server configuration: " + missing.join(", "));
}

function normalizePhone(input) {
  const digits = String(input || "").replace(/\D/g, "");
  if (/^2547\d{8}$/.test(digits)) return digits;
  if (/^07\d{8}$/.test(digits)) return "254" + digits.slice(1);
  if (/^01\d{8}$/.test(digits)) return "254" + digits.slice(1);
  throw new Error("Enter a valid Kenyan M-Pesa phone number.");
}

async function accessToken() {
  requireEnv();
  const auth = Buffer.from(`${CONSUMER_KEY}:${CONSUMER_SECRET}`).toString("base64");
  const response = await fetch(`${DARAJA_BASE}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` }
  });
  if (!response.ok) throw new Error("Daraja authorization failed.");
  const data = await response.json();
  return data.access_token;
}

function timestamp() {
  const d = new Date();
  const p = n => String(n).padStart(2,"0");
  return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function password(ts) {
  return Buffer.from(`${SHORT_CODE}${PASSKEY}${ts}`).toString("base64");
}

app.get("/api/health", (req,res) => res.json({
  ok: true,
  mode: DARAJA_BASE.includes("sandbox") ? "sandbox" : "production",
  plans: PLANS
}));

app.post("/api/mpesa/stkpush", async (req,res) => {
  try {
    const plan = PLANS[req.body.plan];
    if (!plan) return res.status(400).json({ok:false, error:"Invalid plan."});

    const phone = normalizePhone(req.body.phone);
    const ts = timestamp();
    const token = await accessToken();

    const payload = {
      BusinessShortCode: SHORT_CODE,
      Password: password(ts),
      Timestamp: ts,
      TransactionType: "CustomerPayBillOnline",
      Amount: plan.amount,
      PartyA: phone,
      PartyB: SHORT_CODE,
      PhoneNumber: phone,
      CallBackURL: CALLBACK_URL,
      AccountReference: ACCOUNT_REFERENCE,
      TransactionDesc: `${TRANSACTION_DESC} - ${plan.name}`
    };

    const response = await fetch(`${DARAJA_BASE}/mpesa/stkpush/v1/processrequest`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();

    if (!response.ok || data.ResponseCode !== "0") {
      return res.status(502).json({ok:false, error:data.errorMessage || data.ResponseDescription || "STK Push could not be started."});
    }

    // Store CheckoutRequestID + plan + user ID in your database here.
    // Never trust the browser to mark a payment as successful.
    return res.json({
      ok:true,
      message:`You are about to pay KES ${plan.amount} to EarnSmart Kenya Limited.`,
      checkoutRequestId:data.CheckoutRequestID,
      merchantRequestId:data.MerchantRequestID,
      plan:plan.name,
      amount:plan.amount
    });
  } catch (e) {
    return res.status(500).json({ok:false, error:e.message || "Payment request failed."});
  }
});

app.post("/api/mpesa/callback", (req,res) => {
  // Safaricom sends the authoritative async result here.
  // In production: authenticate/allowlist the callback source, persist the raw event,
  // verify the CheckoutRequestID against a pending payment, then activate the plan.
  const callback = req.body?.Body?.stkCallback;
  if (callback) {
    // TODO: replace with database transaction:
    // 1) locate pending payment by CheckoutRequestID
    // 2) ensure amount/plan/customer match the pending record
    // 3) if ResultCode === 0, mark paid and grant entitlement
    // 4) otherwise mark failed/cancelled
    console.log("M-Pesa callback received:", JSON.stringify(callback));
  }
  res.json({ResultCode:0, ResultDesc:"Accepted"});
});

app.listen(PORT, () => console.log(`EarnSmart payment server listening on ${PORT}`));

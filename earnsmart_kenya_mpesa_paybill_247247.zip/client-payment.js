async function startMpesaPayment(plan, phone) {
  const button = document.querySelector(`[data-pay="${plan}"]`);
  if (button) button.disabled = true;
  try {
    const response = await fetch("/api/mpesa/stkpush", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({plan, phone})
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || "Could not start payment.");
    alert(data.message + "\n\nCheck your phone for the M-Pesa prompt.");
    // Poll your own authenticated payment-status endpoint here.
    // Activate membership only after the server confirms ResultCode === 0.
  } catch (err) {
    alert(err.message);
  } finally {
    if (button) button.disabled = false;
  }
}

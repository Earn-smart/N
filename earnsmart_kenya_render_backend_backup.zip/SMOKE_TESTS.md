# EarnSmart backend smoke tests

After deployment:

1. GET `/api/health`
   Expected: `{ "ok": true, "database": "ok" }`

2. GET `/api/plans`
   Expected: Starter 99, Pro 249, Premium 499.

3. Create a test user through the real authentication integration.
   Confirm `/api/me` returns the server-side user record.

4. Test a conversation and message using two test accounts.

5. Test report submission and host/admin report viewing.

6. Use Safaricom Daraja sandbox first.
   Confirm:
   - STK request is recorded as pending.
   - callback updates payment.
   - duplicate callback does not create duplicate entitlements.
   - failed payment remains failed.

7. Test backup:
   - create a pg_dump
   - restore to a separate database
   - verify representative records.

Do not use real customer money until the full payment and restore tests pass.

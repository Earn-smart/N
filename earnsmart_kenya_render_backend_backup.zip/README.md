# EarnSmart Kenya — Render-ready backend

This package is the backend/database foundation for the EarnSmart Kenya website.

## Architecture

Browser
  -> Render Web Service (Node.js + Express)
  -> Render Postgres
  -> external/offsite backups

The backend is responsible for:
- authenticated user records
- conversations and messages
- reports/moderation records
- premium plans and subscriptions
- M-Pesa STK Push + callback storage
- activity logging
- server-side AI endpoint placeholder
- health checks
- rate limiting and security headers

## Important

This is a production-oriented starter, not a claim that every external integration is already live.

Before launch:
1. Connect a real identity provider (Firebase Auth is a good fit for the existing frontend).
2. Replace the development auth headers in `src/auth.js` with verified ID-token validation.
3. Add the chosen AI provider's current API adapter to `/api/ai`.
4. Add and test the current Safaricom Daraja credentials and callback URL.
5. Test M-Pesa callbacks and duplicate callbacks.
6. Configure the frontend to call this API.
7. Set `FRONTEND_ORIGIN` to the real site URL.
8. Set the real host/admin user ID only after identity verification is implemented.
9. Run security and restore tests before accepting real customer payments.

## Database setup

Run `schema.sql` against the Render Postgres database once.

Do not put database credentials in the browser or in `index.html`.

## Render

Recommended services:
- Web Service: this Node/Express backend.
- Managed Postgres: production database.

Render web services provide a public `onrender.com` URL and can also use a custom domain.

## Backups

Use two layers:

### Layer 1 — Render managed recovery

Use a paid Render Postgres instance for point-in-time recovery. Render currently documents a recovery window of the past 3 days on Hobby workspace plans and 7 days on Pro or higher. Free Postgres does not provide recovery capabilities.

### Layer 2 — Independent logical backup

Create periodic `pg_dump` backups and keep them outside the Render web service filesystem. Render's current documentation also provides an official pattern for a scheduled Cron Job that uploads PostgreSQL backups to Amazon S3.

Do not rely on a file stored inside the web service because Render's default service filesystem is ephemeral.

## Restore test

At least occasionally:
1. Create a logical backup.
2. Restore it into a separate test PostgreSQL database.
3. Run `schema`/application smoke tests.
4. Confirm users, payments, subscriptions, messages and reports are present.
5. Record the restore date and result.

## M-Pesa

Plans:
- Starter: KES 99
- Pro: KES 249
- Premium: KES 499

Configured merchant values in this starter:
- PayBill: 247247
- Account reference: 0100187646034

The exact Safaricom STK UI wording is controlled by Safaricom. The application sends the configured transaction description, but should not promise a specific UI sentence.

Important:
- Never trust a browser success message as payment proof.
- Activate premium access only after a verified server-side callback/status result.
- Keep checkout IDs and M-Pesa receipts unique.
- The callback must be idempotent. The current starter has the database uniqueness needed for checkout IDs and receipts, but the subscription activation logic should be strengthened with an idempotency key/transaction guard before launch.

## Authentication

The current `src/auth.js` deliberately uses headers only for development integration testing. These headers are NOT a production authentication system.

For production, verify Firebase/Auth0/another provider's signed token on the server and derive the user identity from that verified token. Never accept `role=admin` or a similar privilege from the browser.

## Security checklist

- HTTPS
- strict CORS
- Helmet
- rate limiting
- input validation
- server-side authorization
- no secrets in frontend code
- M-Pesa callbacks verified and idempotent
- AI API key kept server-side
- database least-privilege credentials
- backups tested by restoration
- moderation/reporting controls
- audit logs for admin actions

## Suggested next integration

Connect the existing `earnsmart_kenya_browser_ready.zip` frontend to:
- `/api/me`
- `/api/plans`
- `/api/conversations`
- `/api/conversations/:id/messages`
- `/api/reports`
- `/api/mpesa/stkpush`
- `/api/mpesa/status/:checkoutRequestId`
- `/api/ai`

Then replace the temporary auth adapter with real token verification.

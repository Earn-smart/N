#!/usr/bin/env bash
set -euo pipefail

# Run this from a machine/container that has pg_dump installed.
# DATABASE_URL must point to the Render Postgres external connection string.
# Store backups outside the web application directory.
#
# Example:
#   DATABASE_URL='postgresql://...' ./backup.sh
#
# For long-term offsite storage, follow Render's current S3 backup guide:
# https://render.com/docs/backup-postgresql-to-s3

: "${DATABASE_URL:?DATABASE_URL is required}"

OUT_DIR="${BACKUP_DIR:-./backups}"
mkdir -p "$OUT_DIR"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_FILE="$OUT_DIR/earnsmart_${STAMP}.dump"

pg_dump \
  --dbname="$DATABASE_URL" \
  --format=custom \
  --no-owner \
  --no-privileges \
  --file="$OUT_FILE"

echo "Backup created: $OUT_FILE"

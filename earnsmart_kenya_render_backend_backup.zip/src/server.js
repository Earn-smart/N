require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { z } = require("zod");
const { query } = require("./db");
const { requireUser, requireRole } = require("./auth");
const { stkPush } = require("./mpesa");

const app = express();
const PORT = process.env.PORT || 10000;

app.set("trust proxy", 1);
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(express.json({ limit: "256kb" }));

const origins = (process.env.FRONTEND_ORIGIN || "")
  .split(",").map(s => s.trim()).filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    if (!origin || origins.length === 0 || origins.includes(origin)) return callback(null, true);
    return callback(new Error("CORS origin denied"));
  },
  credentials: true
}));

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: "draft-8",
  legacyHeaders: false
});
app.use("/api/", apiLimiter);

app.get("/api/health", async (_req, res, next) => {
  try {
    await query("SELECT 1");
    res.json({ ok: true, service: "earnsmart-kenya-api", database: "ok" });
  } catch (err) {
    next(err);
  }
});

app.get("/api/me", requireUser, async (req, res) => {
  const subs = await query(
    `SELECT s.id, s.plan_id, p.name, s.status, s.starts_at, s.ends_at
     FROM subscriptions s JOIN plans p ON p.id=s.plan_id
     WHERE s.user_id=$1 ORDER BY s.created_at DESC`,
    [req.user.id]
  );
  res.json({ user: req.user, subscriptions: subs.rows });
});

app.get("/api/plans", async (_req, res, next) => {
  try {
    const result = await query("SELECT id,name,amount_kes FROM plans WHERE active=true ORDER BY amount_kes");
    res.json({ plans: result.rows });
  } catch (err) { next(err); }
});

app.post("/api/activity", requireUser, async (req, res, next) => {
  try {
    const schema = z.object({
      eventType: z.string().min(1).max(100),
      metadata: z.record(z.string(), z.any()).optional()
    });
    const body = schema.parse(req.body);
    await query(
      "INSERT INTO activity_log(user_id,event_type,metadata) VALUES($1,$2,$3)",
      [req.user.id, body.eventType, body.metadata || {}]
    );
    res.status(201).json({ ok: true });
  } catch (err) { next(err); }
});

app.get("/api/conversations", requireUser, async (req, res, next) => {
  try {
    const result = await query(
      `SELECT c.id,c.kind,c.updated_at
       FROM conversations c
       JOIN conversation_members cm ON cm.conversation_id=c.id
       WHERE cm.user_id=$1
       ORDER BY c.updated_at DESC`,
      [req.user.id]
    );
    res.json({ conversations: result.rows });
  } catch (err) { next(err); }
});

app.post("/api/conversations", requireUser, async (req, res, next) => {
  try {
    const body = z.object({
      kind: z.enum(["host","member","support"]),
      otherUserId: z.string().uuid().optional()
    }).parse(req.body);

    if (body.kind === "host" && !process.env.HOST_USER_ID) {
      return res.status(503).json({ error: "Host account is not configured." });
    }

    const other = body.otherUserId || null;
    const client = await require("./db").pool.connect();
    try {
      await client.query("BEGIN");
      const c = await client.query(
        "INSERT INTO conversations(kind) VALUES($1) RETURNING *", [body.kind]
      );
      await client.query(
        "INSERT INTO conversation_members(conversation_id,user_id) VALUES($1,$2)",
        [c.rows[0].id, req.user.id]
      );
      if (other) {
        await client.query(
          "INSERT INTO conversation_members(conversation_id,user_id) VALUES($1,$2) ON CONFLICT DO NOTHING",
          [c.rows[0].id, other]
        );
      }
      await client.query("COMMIT");
      res.status(201).json({ conversation: c.rows[0] });
    } catch (e) {
      await client.query("ROLLBACK");
      throw e;
    } finally { client.release(); }
  } catch (err) { next(err); }
});

app.get("/api/conversations/:id/messages", requireUser, async (req, res, next) => {
  try {
    const id = z.string().uuid().parse(req.params.id);
    const member = await query(
      "SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2",
      [id, req.user.id]
    );
    if (!member.rows[0]) return res.status(403).json({ error: "Not a conversation member." });

    const result = await query(
      `SELECT id,sender_user_id,body,created_at,read_at
       FROM messages WHERE conversation_id=$1
       ORDER BY created_at ASC LIMIT 200`,
      [id]
    );
    res.json({ messages: result.rows });
  } catch (err) { next(err); }
});

app.post("/api/conversations/:id/messages", requireUser, async (req, res, next) => {
  try {
    const id = z.string().uuid().parse(req.params.id);
    const body = z.object({ body: z.string().trim().min(1).max(5000) }).parse(req.body);

    const member = await query(
      "SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2",
      [id, req.user.id]
    );
    if (!member.rows[0]) return res.status(403).json({ error: "Not a conversation member." });

    const result = await query(
      `INSERT INTO messages(conversation_id,sender_user_id,body)
       VALUES($1,$2,$3) RETURNING id,conversation_id,sender_user_id,body,created_at`,
      [id, req.user.id, body.body]
    );
    await query("UPDATE conversations SET updated_at=now() WHERE id=$1", [id]);
    res.status(201).json({ message: result.rows[0] });
  } catch (err) { next(err); }
});

app.post("/api/reports", requireUser, async (req, res, next) => {
  try {
    const body = z.object({
      reportedUserId: z.string().uuid().optional(),
      conversationId: z.string().uuid().optional(),
      reason: z.string().trim().min(2).max(200),
      details: z.string().trim().max(5000).optional()
    }).parse(req.body);

    const result = await query(
      `INSERT INTO reports(reporter_user_id,reported_user_id,conversation_id,reason,details)
       VALUES($1,$2,$3,$4,$5) RETURNING id,status,created_at`,
      [req.user.id, body.reportedUserId || null, body.conversationId || null, body.reason, body.details || null]
    );
    res.status(201).json({ report: result.rows[0] });
  } catch (err) { next(err); }
});

app.post("/api/mpesa/stkpush", requireUser, async (req, res, next) => {
  try {
    const body = z.object({
      planId: z.enum(["starter","pro","premium"]),
      phone: z.string().regex(/^2547\d{8}$/)
    }).parse(req.body);

    const plan = await query("SELECT * FROM plans WHERE id=$1 AND active=true", [body.planId]);
    if (!plan.rows[0]) return res.status(400).json({ error: "Invalid plan." });

    const p = plan.rows[0];
    const payment = await query(
      `INSERT INTO payments(user_id,plan_id,amount_kes,phone,status)
       VALUES($1,$2,$3,$4,'initiated') RETURNING id`,
      [req.user.id, p.id, p.amount_kes, body.phone]
    );

    const response = await stkPush({
      phone: body.phone,
      amount: p.amount_kes,
      accountReference: process.env.MPESA_ACCOUNT_REFERENCE || "EarnSmart",
      transactionDesc: `EarnSmart Kenya Limited - ${p.name}`
    });

    await query(
      `UPDATE payments SET merchant_request_id=$1,checkout_request_id=$2,status='pending',updated_at=now()
       WHERE id=$3`,
      [response.MerchantRequestID || null, response.CheckoutRequestID || null, payment.rows[0].id]
    );

    res.json({
      ok: true,
      paymentId: payment.rows[0].id,
      checkoutRequestId: response.CheckoutRequestID,
      customerMessage: response.CustomerMessage
    });
  } catch (err) { next(err); }
});

app.get("/api/mpesa/status/:checkoutRequestId", requireUser, async (req, res, next) => {
  try {
    const result = await query(
      `SELECT id,plan_id,amount_kes,status,mpesa_receipt,result_code,result_description,created_at,updated_at
       FROM payments WHERE checkout_request_id=$1 AND user_id=$2`,
      [req.params.checkoutRequestId, req.user.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: "Payment not found." });
    res.json({ payment: result.rows[0] });
  } catch (err) { next(err); }
});

app.post("/api/mpesa/callback", async (req, res, next) => {
  try {
    if (process.env.MPESA_CALLBACK_SECRET) {
      const supplied = req.header("x-mpesa-callback-secret");
      if (supplied !== process.env.MPESA_CALLBACK_SECRET) {
        return res.status(401).json({ error: "Unauthorized callback." });
      }
    }

    const callback = req.body?.Body?.stkCallback;
    if (!callback) return res.status(400).json({ error: "Invalid callback payload." });

    const checkout = callback.CheckoutRequestID;
    const items = callback.CallbackMetadata?.Item || [];
    const map = Object.fromEntries(items.map(x => [x.Name, x.Value]));

    const paymentResult = await query(
      `SELECT * FROM payments WHERE checkout_request_id=$1 LIMIT 1`,
      [checkout]
    );
    if (!paymentResult.rows[0]) {
      console.warn("M-Pesa callback for unknown checkout:", checkout);
      return res.json({ ResultCode: 0, ResultDesc: "Accepted" });
    }

    const payment = paymentResult.rows[0];

    if (callback.ResultCode === 0) {
      const receipt = map.MpesaReceiptNumber || null;
      const client = await require("./db").pool.connect();
      try {
        await client.query("BEGIN");

        const updated = await client.query(
          `UPDATE payments
           SET status='success',result_code=$1,result_description=$2,mpesa_receipt=$3,raw_callback=$4,updated_at=now()
           WHERE id=$5
           RETURNING *`,
          [callback.ResultCode, callback.ResultDesc || null, receipt, req.body, payment.id]
        );

        if (updated.rows[0] && updated.rows[0].user_id && updated.rows[0].plan_id) {
          await client.query(
            `INSERT INTO subscriptions(user_id,plan_id,status,starts_at,ends_at)
             VALUES($1,$2,'active',now(),now()+interval '30 days')`,
            [updated.rows[0].user_id, updated.rows[0].plan_id]
          );
        }

        await client.query("COMMIT");
      } catch (e) {
        await client.query("ROLLBACK");
        throw e;
      } finally { client.release(); }
    } else {
      await query(
        `UPDATE payments
         SET status='failed',result_code=$1,result_description=$2,raw_callback=$3,updated_at=now()
         WHERE checkout_request_id=$4`,
        [callback.ResultCode, callback.ResultDesc || null, req.body, checkout]
      );
    }

    res.json({ ResultCode: 0, ResultDesc: "Accepted" });
  } catch (err) { next(err); }
});

app.post("/api/ai", requireUser, async (req, res, next) => {
  try {
    const body = z.object({
      message: z.string().trim().min(1).max(4000)
    }).parse(req.body);

    if (!process.env.AI_API_URL || !process.env.AI_API_KEY) {
      return res.status(503).json({
        error: "AI provider is not configured yet.",
        safeReply: "AI support is being prepared. You can still use the fraud-safety and online-work guides on EarnSmart Kenya."
      });
    }

    // Provider-specific API calls intentionally omitted.
    // Keep the secret server-side and implement the provider's current API contract here.
    res.status(501).json({ error: "AI provider adapter not installed yet." });
  } catch (err) { next(err); }
});

app.get("/api/admin/reports", requireUser, requireRole("host","admin","moderator"), async (_req, res, next) => {
  try {
    const result = await query(
      `SELECT r.*, u.display_name AS reporter_name
       FROM reports r LEFT JOIN users u ON u.id=r.reporter_user_id
       ORDER BY r.created_at DESC LIMIT 200`
    );
    res.json({ reports: result.rows });
  } catch (err) { next(err); }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  if (err?.name === "ZodError") {
    return res.status(400).json({ error: "Invalid request.", details: err.issues });
  }
  if (err?.message === "CORS origin denied") {
    return res.status(403).json({ error: "Origin not allowed." });
  }
  res.status(500).json({ error: "Internal server error." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`EarnSmart Kenya API listening on ${PORT}`);
});

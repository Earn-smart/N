// Authentication adapter.
// This starter uses an explicit development header so the API can be tested safely
// before a real identity provider is connected. In production, replace this with
// Firebase Admin token verification or another trusted identity provider.
//
// NEVER trust a client-supplied role or admin flag.

const { query } = require("./db");

async function getOrCreateUserFromRequest(req) {
  const subject = req.header("x-auth-subject");
  const email = req.header("x-auth-email") || null;
  const displayName = req.header("x-auth-name") || null;

  if (!subject) {
    return null;
  }

  const existing = await query(
    "SELECT * FROM users WHERE auth_subject = $1 LIMIT 1",
    [subject]
  );

  if (existing.rows[0]) {
    const user = existing.rows[0];
    if (email || displayName) {
      await query(
        "UPDATE users SET email=COALESCE($1,email), display_name=COALESCE($2,display_name), updated_at=now() WHERE id=$3",
        [email, displayName, user.id]
      );
    }
    return user;
  }

  const role = process.env.HOST_USER_ID && subject === process.env.HOST_USER_ID
    ? "host"
    : "member";

  const created = await query(
    `INSERT INTO users(auth_subject,email,display_name,role)
     VALUES($1,$2,$3,$4)
     RETURNING *`,
    [subject, email, displayName, role]
  );

  return created.rows[0];
}

async function requireUser(req, res, next) {
  try {
    const user = await getOrCreateUserFromRequest(req);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    if (user.status !== "active") return res.status(403).json({ error: "Account unavailable." });
    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Insufficient permissions." });
    }
    next();
  };
}

module.exports = { getOrCreateUserFromRequest, requireUser, requireRole };

const axios = require("axios");

function timestamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return d.getUTCFullYear().toString()
    + pad(d.getUTCMonth() + 1)
    + pad(d.getUTCDate())
    + pad(d.getUTCHours())
    + pad(d.getUTCMinutes())
    + pad(d.getUTCSeconds());
}

function password(ts) {
  return Buffer.from(
    `${process.env.MPESA_SHORT_CODE}${process.env.MPESA_PASSKEY}${ts}`
  ).toString("base64");
}

async function getToken() {
  const base = process.env.DARAJA_BASE_URL;
  const key = process.env.DARAJA_CONSUMER_KEY;
  const secret = process.env.DARAJA_CONSUMER_SECRET;
  if (!base || !key || !secret) throw new Error("Daraja credentials are not configured.");

  const auth = Buffer.from(`${key}:${secret}`).toString("base64");
  const response = await axios.get(`${base}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` },
    timeout: 15000
  });
  return response.data.access_token;
}

async function stkPush({ phone, amount, accountReference, transactionDesc }) {
  const base = process.env.DARAJA_BASE_URL;
  const token = await getToken();
  const ts = timestamp();

  const response = await axios.post(
    `${base}/mpesa/stkpush/v1/processrequest`,
    {
      BusinessShortCode: Number(process.env.MPESA_SHORT_CODE),
      Password: password(ts),
      Timestamp: ts,
      TransactionType: "CustomerPayBillOnline",
      Amount: amount,
      PartyA: phone,
      PartyB: Number(process.env.MPESA_SHORT_CODE),
      PhoneNumber: phone,
      CallBackURL: process.env.MPESA_CALLBACK_URL,
      AccountReference: accountReference,
      TransactionDesc: transactionDesc
    },
    {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      timeout: 20000
    }
  );

  return response.data;
}

module.exports = { stkPush };
